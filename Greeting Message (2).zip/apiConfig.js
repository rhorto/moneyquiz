// Configuration for the backend API
const config = {
  // API base URL - would be different in production
  apiBaseUrl: 'http://localhost:5000/api',
  
  // Endpoints
  endpoints: {
    // Fast Track Wizard endpoints
    fastTrack: {
      niches: '/fasttrack/niches',
      offers: '/fasttrack/offers',
      contentTypes: '/fasttrack/content-types',
      generatePlan: '/fasttrack/generate-plan',
      savePlan: '/fasttrack/save-plan',
      getUserPlan: '/fasttrack/plan',
      updateProgress: '/fasttrack/plan/progress'
    },
    
    // Niche Analysis endpoints
    niches: {
      search: '/niches/search',
      trending: '/niches/trending',
      competition: '/niches/competition',
      profitability: '/niches/profitability',
      details: '/niches/details'
    },
    
    // Affiliate Program endpoints
    affiliates: {
      search: '/affiliates/search',
      recommended: '/affiliates/recommended',
      popular: '/affiliates/popular',
      details: '/affiliates/details',
      apply: '/affiliates/apply'
    },
    
    // Content Strategy endpoints
    content: {
      templates: '/content/templates',
      calendar: '/content/calendar',
      keywords: '/content/keywords',
      generator: '/content/generator',
      adCost: '/content/ad-cost'
    },
    
    // Analytics endpoints
    analytics: {
      overview: '/analytics/overview',
      performance: '/analytics/performance',
      revenue: '/analytics/revenue',
      conversion: '/analytics/conversion',
      attribution: '/analytics/attribution'
    }
  },
  
  // Mock user data for development
  mockUser: {
    id: 'user123',
    name: 'John Doe',
    email: 'john@example.com',
    tier: 'expert' // free, basic, medium, expert
  }
};

module.exports = config;
