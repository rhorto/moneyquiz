# MongoDB Atlas Setup Guide

This guide will help you set up a free MongoDB Atlas database for the Affiliate Dashboard.

## Step 1: Create a MongoDB Atlas Account

1. Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas/register)
2. Sign up for a free account
3. Complete the registration process

## Step 2: Create a Free Tier Cluster

1. Click "Build a Database"
2. Select "FREE" tier option
3. Choose a cloud provider (AWS, Google Cloud, or Azure) and a region closest to your users
4. Click "Create Cluster" (this may take a few minutes to provision)

## Step 3: Set Up Database Access

1. In the left sidebar, click "Database Access"
2. Click "Add New Database User"
3. Create a username and password (save these credentials securely)
4. Set privileges to "Read and Write to Any Database"
5. Click "Add User"

## Step 4: Configure Network Access

1. In the left sidebar, click "Network Access"
2. Click "Add IP Address"
3. For development, you can select "Allow Access from Anywhere" (0.0.0.0/0)
4. For production, you should restrict to specific IP addresses
5. Click "Confirm"

## Step 5: Get Connection String

1. Go back to "Database" section
2. Click "Connect" on your cluster
3. Select "Connect your application"
4. Copy the connection string
5. Replace `<password>` with your database user's password
6. Replace `<dbname>` with "affiliate-dashboard"

## Step 6: Update Environment Variables

1. In your backend project, update the `.env` file with your MongoDB connection string:
```
MONGODB_URI=mongodb+srv://username:password@cluster0.mongodb.net/affiliate-dashboard?retryWrites=true&w=majority
```

## Important Notes

- The free tier provides 512MB of storage
- Clusters on the free tier will automatically pause after 60 days of inactivity
- Data is automatically backed up
- You can upgrade to a paid tier at any time if you need more resources
