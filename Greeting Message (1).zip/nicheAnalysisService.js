// Mock data service for niche analysis
const niches = [
  {
    id: "niche1",
    name: "Home Fitness Equipment",
    demand: "High",
    competition: "Medium",
    profitPotential: "High",
    isRecommended: true,
    description: "Home workout equipment including treadmills, exercise bikes, weights, and fitness accessories.",
    monthlySearchVolume: 450000,
    averageCommission: "12%",
    averageOrderValue: "$250",
    conversionRate: "2.8%",
    topKeywords: [
      { keyword: "best home treadmill", volume: 22000, competition: "Medium", difficulty: 42 },
      { keyword: "affordable exercise bike", volume: 18000, competition: "Medium", difficulty: 38 },
      { keyword: "home gym equipment", volume: 33000, competition: "High", difficulty: 65 },
      { keyword: "adjustable dumbbells set", volume: 12000, competition: "Low", difficulty: 27 },
      { keyword: "yoga mat", volume: 40000, competition: "Medium", difficulty: 45 }
    ],
    trends: [
      { month: "Jan", searches: 380000 },
      { month: "Feb", searches: 410000 },
      { month: "Mar", searches: 430000 },
      { month: "Apr", searches: 450000 },
      { month: "May", searches: 470000 },
      { month: "Jun", searches: 460000 }
    ],
    competitorCount: 245,
    topCompetitors: [
      { name: "FitnessGear.com", domainAuthority: 78, monthlyTraffic: 1200000 },
      { name: "HomeGymReviews.com", domainAuthority: 65, monthlyTraffic: 850000 },
      { name: "WorkoutFromHome.net", domainAuthority: 52, monthlyTraffic: 420000 }
    ]
  },
  {
    id: "niche2",
    name: "Smart Home Devices",
    demand: "High",
    competition: "High",
    profitPotential: "Medium",
    isRecommended: false,
    description: "Smart speakers, security systems, lighting, thermostats, and other connected home devices.",
    monthlySearchVolume: 680000,
    averageCommission: "8%",
    averageOrderValue: "$180",
    conversionRate: "2.2%",
    topKeywords: [
      { keyword: "best smart speakers", volume: 33000, competition: "High", difficulty: 68 },
      { keyword: "smart home security system", volume: 27000, competition: "High", difficulty: 72 },
      { keyword: "smart thermostat reviews", volume: 18000, competition: "Medium", difficulty: 54 },
      { keyword: "affordable smart lights", volume: 14000, competition: "Medium", difficulty: 47 },
      { keyword: "smart home hub comparison", volume: 9000, competition: "Medium", difficulty: 51 }
    ],
    trends: [
      { month: "Jan", searches: 620000 },
      { month: "Feb", searches: 640000 },
      { month: "Mar", searches: 650000 },
      { month: "Apr", searches: 670000 },
      { month: "May", searches: 680000 },
      { month: "Jun", searches: 690000 }
    ],
    competitorCount: 380,
    topCompetitors: [
      { name: "SmartHomeGuide.com", domainAuthority: 82, monthlyTraffic: 1800000 },
      { name: "ConnectedLiving.com", domainAuthority: 75, monthlyTraffic: 1400000 },
      { name: "TechHome.io", domainAuthority: 68, monthlyTraffic: 950000 }
    ]
  },
  {
    id: "niche3",
    name: "Sustainable Living Products",
    demand: "Medium",
    competition: "Low",
    profitPotential: "Medium",
    isRecommended: true,
    description: "Eco-friendly household items, reusable products, energy-efficient appliances, and sustainable fashion.",
    monthlySearchVolume: 320000,
    averageCommission: "15%",
    averageOrderValue: "$85",
    conversionRate: "3.1%",
    topKeywords: [
      { keyword: "eco friendly products", volume: 22000, competition: "Medium", difficulty: 45 },
      { keyword: "reusable shopping bags", volume: 18000, competition: "Low", difficulty: 32 },
      { keyword: "sustainable clothing brands", volume: 14000, competition: "Medium", difficulty: 48 },
      { keyword: "zero waste kitchen products", volume: 9000, competition: "Low", difficulty: 28 },
      { keyword: "energy efficient appliances", volume: 16000, competition: "Medium", difficulty: 52 }
    ],
    trends: [
      { month: "Jan", searches: 280000 },
      { month: "Feb", searches: 290000 },
      { month: "Mar", searches: 310000 },
      { month: "Apr", searches: 320000 },
      { month: "May", searches: 340000 },
      { month: "Jun", searches: 350000 }
    ],
    competitorCount: 165,
    topCompetitors: [
      { name: "EcoLifeGuide.com", domainAuthority: 62, monthlyTraffic: 580000 },
      { name: "SustainableLiving.org", domainAuthority: 58, monthlyTraffic: 420000 },
      { name: "GreenChoices.net", domainAuthority: 45, monthlyTraffic: 280000 }
    ]
  },
  {
    id: "niche4",
    name: "Pet Health Monitoring",
    demand: "Medium",
    competition: "Low",
    profitPotential: "Medium",
    isRecommended: true,
    description: "Pet health trackers, smart feeders, monitoring cameras, and health supplements for pets.",
    monthlySearchVolume: 280000,
    averageCommission: "18%",
    averageOrderValue: "$120",
    conversionRate: "2.9%",
    topKeywords: [
      { keyword: "pet health tracker", volume: 12000, competition: "Low", difficulty: 35 },
      { keyword: "smart pet feeder", volume: 9000, competition: "Low", difficulty: 32 },
      { keyword: "pet monitoring camera", volume: 15000, competition: "Medium", difficulty: 44 },
      { keyword: "dog health supplements", volume: 18000, competition: "Medium", difficulty: 48 },
      { keyword: "cat health monitor", volume: 7000, competition: "Low", difficulty: 30 }
    ],
    trends: [
      { month: "Jan", searches: 250000 },
      { month: "Feb", searches: 260000 },
      { month: "Mar", searches: 270000 },
      { month: "Apr", searches: 280000 },
      { month: "May", searches: 290000 },
      { month: "Jun", searches: 295000 }
    ],
    competitorCount: 135,
    topCompetitors: [
      { name: "PetHealthGuide.com", domainAuthority: 58, monthlyTraffic: 420000 },
      { name: "SmartPetOwner.com", domainAuthority: 52, monthlyTraffic: 350000 },
      { name: "PetTechReviews.net", domainAuthority: 45, monthlyTraffic: 220000 }
    ]
  },
  {
    id: "niche5",
    name: "Digital Marketing Tools",
    demand: "High",
    competition: "Medium",
    profitPotential: "High",
    isRecommended: true,
    description: "Email marketing software, SEO tools, social media management platforms, and analytics solutions.",
    monthlySearchVolume: 520000,
    averageCommission: "30%",
    averageOrderValue: "$150",
    conversionRate: "3.5%",
    topKeywords: [
      { keyword: "best email marketing software", volume: 18000, competition: "High", difficulty: 65 },
      { keyword: "affordable SEO tools", volume: 22000, competition: "Medium", difficulty: 55 },
      { keyword: "social media management platform", volume: 15000, competition: "Medium", difficulty: 58 },
      { keyword: "marketing analytics tools", volume: 12000, competition: "Medium", difficulty: 52 },
      { keyword: "small business marketing software", volume: 9000, competition: "Medium", difficulty: 48 }
    ],
    trends: [
      { month: "Jan", searches: 480000 },
      { month: "Feb", searches: 490000 },
      { month: "Mar", searches: 500000 },
      { month: "Apr", searches: 510000 },
      { month: "May", searches: 520000 },
      { month: "Jun", searches: 530000 }
    ],
    competitorCount: 285,
    topCompetitors: [
      { name: "MarketingToolsGuru.com", domainAuthority: 72, monthlyTraffic: 980000 },
      { name: "DigitalMarketingPro.com", domainAuthority: 68, monthlyTraffic: 850000 },
      { name: "MarketingSoftwareReviews.net", domainAuthority: 61, monthlyTraffic: 620000 }
    ]
  },
  {
    id: "niche6",
    name: "Online Education Courses",
    demand: "Very High",
    competition: "High",
    profitPotential: "High",
    isRecommended: false,
    description: "Online courses for professional skills, languages, hobbies, and academic subjects.",
    monthlySearchVolume: 780000,
    averageCommission: "40%",
    averageOrderValue: "$200",
    conversionRate: "2.5%",
    topKeywords: [
      { keyword: "best online courses", volume: 33000, competition: "High", difficulty: 75 },
      { keyword: "learn programming online", volume: 27000, competition: "High", difficulty: 68 },
      { keyword: "online language courses", volume: 22000, competition: "High", difficulty: 70 },
      { keyword: "photography classes online", volume: 15000, competition: "Medium", difficulty: 55 },
      { keyword: "online certification courses", volume: 18000, competition: "High", difficulty: 72 }
    ],
    trends: [
      { month: "Jan", searches: 720000 },
      { month: "Feb", searches: 740000 },
      { month: "Mar", searches: 750000 },
      { month: "Apr", searches: 760000 },
      { month: "May", searches: 770000 },
      { month: "Jun", searches: 780000 }
    ],
    competitorCount: 420,
    topCompetitors: [
      { name: "OnlineCoursesReview.com", domainAuthority: 85, monthlyTraffic: 2200000 },
      { name: "eLearningGuide.com", domainAuthority: 78, monthlyTraffic: 1800000 },
      { name: "SkillCoursesFinder.net", domainAuthority: 72, monthlyTraffic: 1400000 }
    ]
  },
  {
    id: "niche7",
    name: "Plant-Based Diet Products",
    demand: "Medium",
    competition: "Low",
    profitPotential: "Medium",
    isRecommended: true,
    description: "Vegan food products, plant-based protein supplements, meal kits, and cookbooks.",
    monthlySearchVolume: 310000,
    averageCommission: "12%",
    averageOrderValue: "$65",
    conversionRate: "3.2%",
    topKeywords: [
      { keyword: "best vegan protein powder", volume: 18000, competition: "Medium", difficulty: 48 },
      { keyword: "plant based meal kits", volume: 12000, competition: "Low", difficulty: 35 },
      { keyword: "vegan cookbook", volume: 15000, competition: "Medium", difficulty: 42 },
      { keyword: "plant based diet for beginners", volume: 22000, competition: "Low", difficulty: 38 },
      { keyword: "vegan supplements", volume: 9000, competition: "Low", difficulty: 32 }
    ],
    trends: [
      { month: "Jan", searches: 280000 },
      { month: "Feb", searches: 290000 },
      { month: "Mar", searches: 300000 },
      { month: "Apr", searches: 310000 },
      { month: "May", searches: 320000 },
      { month: "Jun", searches: 330000 }
    ],
    competitorCount: 175,
    topCompetitors: [
      { name: "VeganLifestyle.com", domainAuthority: 65, monthlyTraffic: 620000 },
      { name: "PlantBasedDiet.org", domainAuthority: 58, monthlyTraffic: 480000 },
      { name: "VeganProductReviews.net", domainAuthority: 48, monthlyTraffic: 320000 }
    ]
  },
  {
    id: "niche8",
    name: "Remote Work Tools",
    demand: "High",
    competition: "Medium",
    profitPotential: "Medium",
    isRecommended: true,
    description: "Home office equipment, productivity software, ergonomic furniture, and remote collaboration tools.",
    monthlySearchVolume: 480000,
    averageCommission: "10%",
    averageOrderValue: "$180",
    conversionRate: "2.7%",
    topKeywords: [
      { keyword: "best home office desk", volume: 22000, competition: "Medium", difficulty: 52 },
      { keyword: "ergonomic office chair", volume: 18000, competition: "Medium", difficulty: 55 },
      { keyword: "remote work software", volume: 15000, competition: "Medium", difficulty: 48 },
      { keyword: "productivity tools for remote work", volume: 12000, competition: "Low", difficulty: 42 },
      { keyword: "video conferencing equipment", volume: 9000, competition: "Medium", difficulty: 50 }
    ],
    trends: [
      { month: "Jan", searches: 450000 },
      { month: "Feb", searches: 460000 },
      { month: "Mar", searches: 470000 },
      { month: "Apr", searches: 480000 },
      { month: "May", searches: 490000 },
      { month: "Jun", searches: 500000 }
    ],
    competitorCount: 210,
    topCompetitors: [
      { name: "RemoteWorkGear.com", domainAuthority: 68, monthlyTraffic: 780000 },
      { name: "HomeOfficeSetup.com", domainAuthority: 62, monthlyTraffic: 650000 },
      { name: "ProductivityToolsReview.net", domainAuthority: 55, monthlyTraffic: 420000 }
    ]
  }
];

// Mock data service for niche analysis
const nicheAnalysisService = {
  // Get trending niches
  getTrendingNiches: () => {
    // Sort niches by search volume trends (using the last month's data)
    return niches.map(niche => {
      const lastMonthTrend = niche.trends[niche.trends.length - 1].searches;
      const previousMonthTrend = niche.trends[niche.trends.length - 2].searches;
      const growthRate = ((lastMonthTrend - previousMonthTrend) / previousMonthTrend) * 100;
      
      return {
        id: niche.id,
        name: niche.name,
        demand: niche.demand,
        competition: niche.competition,
        profitPotential: niche.profitPotential,
        monthlySearchVolume: niche.monthlySearchVolume,
        growthRate: parseFloat(growthRate.toFixed(1)),
        isRecommended: niche.isRecommended
      };
    }).sort((a, b) => b.growthRate - a.growthRate).slice(0, 5);
  },
  
  // Search niches by keyword
  searchNiches: (keyword) => {
    if (!keyword) return [];
    
    const lowercaseKeyword = keyword.toLowerCase();
    return niches.filter(niche => 
      niche.name.toLowerCase().includes(lowercaseKeyword) || 
      niche.description.toLowerCase().includes(lowercaseKeyword) ||
      niche.topKeywords.some(k => k.keyword.toLowerCase().includes(lowercaseKeyword))
    ).map(niche => ({
      id: niche.id,
      name: niche.name,
      demand: niche.demand,
      competition: niche.competition,
      profitPotential: niche.profitPotential,
      description: niche.description,
      monthlySearchVolume: niche.monthlySearchVolume,
      isRecommended: niche.isRecommended
    }));
  },
  
  // Get niche competition analysis
  getNicheCompetition: (nicheId) => {
    const niche = niches.find(n => n.id === nicheId);
    if (!niche) return null;
    
    return {
      id: niche.id,
      name: niche.name,
      competitionLevel: niche.competition,
      competitorCount: niche.competitorCount,
      topCompetitors: niche.topCompetitors,
      difficultyScore: niche.competition === "High" ? 75 : niche.competition === "Medium" ? 50 : 25,
      competitionInsights: [
        {
          factor: "Market Saturation",
          score: niche.competition === "High" ? 8 : niche.competition === "Medium" ? 5 : 3,
          description: `The ${niche.name} niche has ${niche.competition.toLowerCase()} market saturation with ${niche.competitorCount} significant competitors.`
        },
        {
          factor: "Content Competition",
          score: niche.competition === "High" ? 7 : niche.competition === "Medium" ? 5 : 2,
          description: `Content creation in this niche is ${niche.competition.toLowerCase()}ly competitive, requiring ${niche.competition === "High" ? "exceptional" : niche.competition === "Medium" ? "good" : "basic"} quality to stand out.`
        },
        {
          factor: "Keyword Difficulty",
          score: niche.competition === "High" ? 8 : niche.competition === "Medium" ? 6 : 3,
          description: `Keywords in this niche have ${niche.competition.toLowerCase()} competition levels, with an average difficulty score of ${niche.competition === "High" ? "65+" : niche.competition === "Medium" ? "45-65" : "below 45"}.`
        },
        {
          factor: "Barrier to Entry",
          score: niche.competition === "High" ? 9 : niche.competition === "Medium" ? 6 : 3,
          description: `The barrier to entry for new affiliates is ${niche.competition.toLowerCase()}, requiring ${niche.competition === "High" ? "significant" : niche.competition === "Medium" ? "moderate" : "minimal"} resources and expertise.`
        }
      ]
    };
  },
  
  // Get niche profitability analysis
  getNicheProfitability: (nicheId) => {
    const niche = niches.find(n => n.id === nicheId);
    if (!niche) return null;
    
    // Calculate potential monthly earnings
    const averageCommissionRate = parseFloat(niche.averageCommission.replace('%', '')) / 100;
    const averageOrderValue = pa
(Content truncated due to size limit. Use line ranges to read in chunks)