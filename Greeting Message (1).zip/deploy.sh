#!/bin/bash

# Script to prepare and deploy the Affiliate Dashboard to free hosting services
# This script automates the deployment process for both backend and frontend

echo "===== Affiliate Dashboard Deployment Script ====="
echo "This script will help you deploy the dashboard to Render.com and Vercel"
echo ""

# Create deployment package for backend
echo "Creating deployment package for backend..."
cd /home/ubuntu/affiliate_dashboard_backend
npm install

# Create a .env file from example if it doesn't exist
if [ ! -f .env ]; then
  echo "Creating .env file from template..."
  cp .env.example .env
  echo "Please update the .env file with your MongoDB Atlas connection string"
  echo "and other environment variables before continuing."
  read -p "Press Enter to continue after updating .env..."
fi

# Create deployment package for frontend
echo "Creating deployment package for frontend..."
cd /home/ubuntu/affiliate_dashboard_frontend
npm install
npm run build

echo ""
echo "===== Deployment Packages Created ====="
echo ""
echo "To complete deployment:"
echo ""
echo "1. Backend (Render.com):"
echo "   - Create a new Web Service on Render.com"
echo "   - Connect your GitHub repository or upload the backend files"
echo "   - Set environment variables from your .env file"
echo "   - Deploy the service"
echo ""
echo "2. Frontend (Vercel):"
echo "   - Create a new project on Vercel"
echo "   - Connect your GitHub repository or upload the frontend files"
echo "   - Set the NEXT_PUBLIC_API_URL environment variable to your Render.com backend URL"
echo "   - Deploy the project"
echo ""
echo "For detailed instructions, refer to the deployment-guide.md file"
echo ""
echo "===== Deployment Preparation Complete ====="
